import java.util.*;

public class Metrics {

    public static void printNetworkMetrics(Graph graph) {
        System.out.println("\n================ NETWORK METRICS ================");
        int n = graph.size();
        int e = graph.edgeCount();

        System.out.println("Number of users/nodes       : " + n);
        System.out.println("Number of interactions      : " + e);
        System.out.println("Total interaction strength  : " + graph.totalInteractionStrength());

        double possible = n <= 1 ? 0 : (double) n * (n - 1) / 2;
        double density = possible == 0 ? 0 : e / possible;
        System.out.printf("Graph density               : %.2f%%%n", density * 100);

        if (n > 0) {
            double avgDegree = (2.0 * e) / n;
            System.out.printf("Average degree              : %.2f%n", avgDegree);

            String maxUser = null;
            long maxStrength = -1;

            for (String u : graph.users()) {
                long strength = graph.weightedDegree(u);
                if (strength > maxStrength) {
                    maxStrength = strength;
                    maxUser = u;
                }
            }

            System.out.println("Most connected by strength  : " + maxUser
                    + " (" + maxStrength + ")");
        }
    }

    public static void printCommunityReport(Graph graph, Map<String, Integer> community) {
        Map<Integer, List<String>> groups = groupMembers(community);

        System.out.println("\n============== COMMUNITY REPORT ================");
        System.out.println("Community count : " + groups.size());

        for (Map.Entry<Integer, List<String>> entry : groups.entrySet()) {
            int id = entry.getKey();
            List<String> members = entry.getValue();

            long internalStrength = 0;
            for (int i = 0; i < members.size(); i++) {
                for (int j = i + 1; j < members.size(); j++) {
                    internalStrength += graph.weight(members.get(i), members.get(j));
                }
            }

            System.out.println("\nCommunity " + id);
            System.out.println("Members              : " + String.join(", ", members));
            System.out.println("Community size       : " + members.size());
            System.out.println("Internal interaction : " + internalStrength);
        }

        double modularity = LouvainDetector.modularity(graph, community);
        System.out.printf("%nModularity score : %.4f%n", modularity);
        System.out.println("Higher positive modularity generally indicates stronger community structure.");
    }

    private static Map<Integer, List<String>> groupMembers(Map<String, Integer> community) {
        Map<Integer, List<String>> groups = new TreeMap<>();

        for (Map.Entry<String, Integer> e : community.entrySet()) {
            groups.computeIfAbsent(e.getValue(), k -> new ArrayList<>()).add(e.getKey());
        }
        return groups;
    }
}
