import java.util.*;

public class LouvainDetector {
    private final Graph graph;

    public LouvainDetector(Graph graph) {
        this.graph = graph;
    }

    /*
     * Simplified Louvain modularity optimization.
     *
     * Phase 1:
     *   Each node starts in its own community.
     *   For every node, test moving it to each neighboring community.
     *   Keep a move when modularity gain is positive.
     *
     * Phase 2:
     *   Compress communities into super-nodes and repeat.
     *
     * This is an educational implementation intended to demonstrate the
     * DSA idea behind Louvain rather than a production-scale library.
     */
    public Map<String, Integer> detect() {
        List<String> nodes = new ArrayList<>(graph.users());
        Map<String, Integer> community = new LinkedHashMap<>();

        for (int i = 0; i < nodes.size(); i++) {
            community.put(nodes.get(i), i);
        }

        if (nodes.size() <= 1) return community;

        boolean changed = true;
        int maxPasses = Math.max(5, nodes.size() * 2);

        for (int pass = 0; pass < maxPasses && changed; pass++) {
            changed = false;

            for (String node : nodes) {
                int current = community.get(node);

                Set<Integer> candidates = new LinkedHashSet<>();
                candidates.add(current);
                for (String neighbor : graph.neighbors(node).keySet()) {
                    candidates.add(community.get(neighbor));
                }

                double bestGain = 0.0;
                int bestCommunity = current;

                for (int candidate : candidates) {
                    if (candidate == current) continue;

                    Map<String, Integer> test = new LinkedHashMap<>(community);
                    test.put(node, candidate);

                    double before = modularity(graph, community);
                    double after = modularity(graph, test);
                    double gain = after - before;

                    if (gain > bestGain + 1e-10) {
                        bestGain = gain;
                        bestCommunity = candidate;
                    }
                }

                if (bestCommunity != current) {
                    community.put(node, bestCommunity);
                    changed = true;
                }
            }
        }

        return renumber(community);
    }

    public static double modularity(Graph graph, Map<String, Integer> community) {
        double m = graph.totalInteractionStrength();
        if (m == 0) return 0.0;

        double q = 0.0;
        List<String> nodes = new ArrayList<>(graph.users());

        // Weighted undirected modularity:
        // Q = (1 / 2m) sum_ij [Aij - (ki*kj)/(2m)] delta(ci,cj)
        for (String i : nodes) {
            long ki = graph.weightedDegree(i);

            for (String j : nodes) {
                if (!Objects.equals(community.get(i), community.get(j))) continue;

                long kj = graph.weightedDegree(j);
                double aij = graph.weight(i, j);
                q += aij - ((double) ki * kj) / (2.0 * m);
            }
        }

        return q / (2.0 * m);
    }

    private Map<String, Integer> renumber(Map<String, Integer> old) {
        Map<Integer, Integer> ids = new LinkedHashMap<>();
        Map<String, Integer> result = new LinkedHashMap<>();
        int next = 1;

        for (String node : old.keySet()) {
            int oldId = old.get(node);
            if (!ids.containsKey(oldId)) ids.put(oldId, next++);
            result.put(node, ids.get(oldId));
        }
        return result;
    }
}
