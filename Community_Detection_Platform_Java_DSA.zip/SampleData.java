public class SampleData {
    public static void load(Graph graph) {
        String[] users = {
            "Aarav", "Diya", "Kabir", "Meera", "Rohan",
            "Ananya", "Vikram", "Ishita", "Arjun", "Sneha"
        };

        for (String user : users) graph.addUser(user);

        // Group 1: Aarav, Diya, Kabir, Meera, Rohan
        graph.addInteraction("Aarav", "Diya", 8);
        graph.addInteraction("Aarav", "Kabir", 7);
        graph.addInteraction("Diya", "Kabir", 9);
        graph.addInteraction("Diya", "Meera", 6);
        graph.addInteraction("Kabir", "Meera", 7);
        graph.addInteraction("Kabir", "Rohan", 8);
        graph.addInteraction("Meera", "Rohan", 7);
        graph.addInteraction("Aarav", "Rohan", 5);

        // Group 2: Ananya, Vikram, Ishita, Arjun, Sneha
        graph.addInteraction("Ananya", "Vikram", 9);
        graph.addInteraction("Ananya", "Ishita", 7);
        graph.addInteraction("Vikram", "Ishita", 8);
        graph.addInteraction("Vikram", "Arjun", 7);
        graph.addInteraction("Ishita", "Sneha", 9);
        graph.addInteraction("Arjun", "Sneha", 8);
        graph.addInteraction("Ananya", "Sneha", 6);
        graph.addInteraction("Ishita", "Arjun", 7);

        // Weak links between communities.
        graph.addInteraction("Rohan", "Ananya", 1);
        graph.addInteraction("Meera", "Ishita", 1);
    }
}
