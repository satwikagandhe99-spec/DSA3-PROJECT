import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Graph {
    // Adjacency-list representation:
    // user -> (neighbor -> edge weight)
    private final Map<String, Map<String, Integer>> adjacency = new LinkedHashMap<>();

    public boolean addUser(String id) {
        if (id == null || id.isBlank() || adjacency.containsKey(id)) return false;
        adjacency.put(id, new LinkedHashMap<>());
        return true;
    }

    public boolean containsUser(String id) {
        return adjacency.containsKey(id);
    }

    public int size() {
        return adjacency.size();
    }

    public boolean addInteraction(String a, String b, int weight) {
        if (!containsUser(a) || !containsUser(b) || a.equals(b) || weight < 1) {
            return false;
        }
        adjacency.get(a).put(b, weight);
        adjacency.get(b).put(a, weight);
        return true;
    }

    public boolean removeUser(String id) {
        if (!adjacency.containsKey(id)) return false;

        for (String neighbor : new ArrayList<>(adjacency.get(id).keySet())) {
            adjacency.get(neighbor).remove(id);
        }
        adjacency.remove(id);
        return true;
    }

    public Set<String> users() {
        return Collections.unmodifiableSet(adjacency.keySet());
    }

    public Map<String, Integer> neighbors(String id) {
        Map<String, Integer> result = adjacency.get(id);
        if (result == null) return Collections.emptyMap();
        return Collections.unmodifiableMap(result);
    }

    public int weight(String a, String b) {
        return adjacency.getOrDefault(a, Collections.emptyMap()).getOrDefault(b, 0);
    }

    public int edgeCount() {
        int total = 0;
        for (Map<String, Integer> n : adjacency.values()) total += n.size();
        return total / 2;
    }

    public long totalInteractionStrength() {
        long total = 0;
        for (String u : adjacency.keySet()) {
            for (int w : adjacency.get(u).values()) total += w;
        }
        return total / 2;
    }

    public int degree(String id) {
        return adjacency.getOrDefault(id, Collections.emptyMap()).size();
    }

    public long weightedDegree(String id) {
        long total = 0;
        for (int w : adjacency.getOrDefault(id, Collections.emptyMap()).values()) total += w;
        return total;
    }

    public List<String> bfs(String start) {
        List<String> order = new ArrayList<>();
        if (!containsUser(start)) return order;

        Set<String> visited = new HashSet<>();
        Queue<String> queue = new ArrayDeque<>();
        visited.add(start);
        queue.add(start);

        while (!queue.isEmpty()) {
            String current = queue.remove();
            order.add(current);

            for (String next : adjacency.get(current).keySet()) {
                if (visited.add(next)) queue.add(next);
            }
        }
        return order;
    }

    public List<String> dfs(String start) {
        List<String> order = new ArrayList<>();
        if (!containsUser(start)) return order;

        Set<String> visited = new HashSet<>();
        dfsRecursive(start, visited, order);
        return order;
    }

    private void dfsRecursive(String current, Set<String> visited, List<String> order) {
        visited.add(current);
        order.add(current);

        for (String next : adjacency.get(current).keySet()) {
            if (!visited.contains(next)) dfsRecursive(next, visited, order);
        }
    }

    public void printGraph() {
        System.out.println("\n================ WEIGHTED GRAPH =================");
        if (adjacency.isEmpty()) {
            System.out.println("Graph is empty.");
            return;
        }

        for (String user : adjacency.keySet()) {
            System.out.print(user + " -> ");
            if (adjacency.get(user).isEmpty()) {
                System.out.println("(no interactions)");
                continue;
            }

            List<String> parts = new ArrayList<>();
            for (Map.Entry<String, Integer> e : adjacency.get(user).entrySet()) {
                parts.add(e.getKey() + "[w=" + e.getValue() + "]");
            }
            System.out.println(String.join(", ", parts));
        }

        System.out.println("Users: " + size()
                + " | Edges: " + edgeCount()
                + " | Total interaction strength: " + totalInteractionStrength());
    }

    // CSV format: source,target,weight
    public int loadCSV(String path) throws IOException {
        int count = 0;
        List<String> lines = Files.readAllLines(Paths.get(path));

        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            String[] p = line.split(",");
            if (p.length < 3) continue;

            String a = p[0].trim();
            String b = p[1].trim();
            if (a.equalsIgnoreCase("source") && b.equalsIgnoreCase("target")) continue;

            try {
                int weight = Integer.parseInt(p[2].trim());
                if (!containsUser(a)) addUser(a);
                if (!containsUser(b)) addUser(b);

                if (addInteraction(a, b, weight)) count++;
            } catch (NumberFormatException ignored) {
                // Ignore malformed rows.
            }
        }
        return count;
    }

    public void saveCSV(String path) throws IOException {
        Path output = Paths.get(path);
        if (output.getParent() != null) Files.createDirectories(output.getParent());

        try (BufferedWriter writer = Files.newBufferedWriter(output)) {
            writer.write("source,target,weight");
            writer.newLine();

            Set<String> written = new HashSet<>();
            for (String a : adjacency.keySet()) {
                for (Map.Entry<String, Integer> e : adjacency.get(a).entrySet()) {
                    String b = e.getKey();
                    String key1 = a + "\u0000" + b;
                    String key2 = b + "\u0000" + a;

                    if (!written.contains(key1) && !written.contains(key2)) {
                        writer.write(a + "," + b + "," + e.getValue());
                        writer.newLine();
                        written.add(key1);
                    }
                }
            }
        }
    }
}
