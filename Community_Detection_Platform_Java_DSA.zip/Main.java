import java.io.IOException;
import java.util.*;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Graph graph = new Graph();

    public static void main(String[] args) {
        SampleData.load(graph);

        System.out.println("\n====================================================");
        System.out.println("       COMMUNITY DETECTION PLATFORM - JAVA DSA");
        System.out.println("====================================================");
        System.out.println("Weighted Graph + BFS/DFS + Louvain + Metrics");
        System.out.println("Sample network loaded. You can edit it from the menu.");

        while (true) {
            printMenu();
            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {
                    case 1 -> addUser();
                    case 2 -> addInteraction();
                    case 3 -> removeUser();
                    case 4 -> displayGraph();
                    case 5 -> traverse();
                    case 6 -> detectCommunities();
                    case 7 -> showMetrics();
                    case 8 -> loadCSV();
                    case 9 -> saveCSV();
                    case 0 -> {
                        System.out.println("Exiting... Thank you!");
                        return;
                    }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Operation failed: " + e.getMessage());
            }

            pause();
        }
    }

    private static void printMenu() {
        System.out.println("\n-------------------- MAIN MENU ---------------------");
        System.out.println("1. Add user/node");
        System.out.println("2. Add interaction/weighted edge");
        System.out.println("3. Remove user/node");
        System.out.println("4. Display weighted graph");
        System.out.println("5. BFS / DFS traversal");
        System.out.println("6. Detect communities (Louvain)");
        System.out.println("7. Show network & community metrics");
        System.out.println("8. Load interactions from CSV");
        System.out.println("9. Save current graph to CSV");
        System.out.println("0. Exit");
        System.out.println("-----------------------------------------------------");
    }

    private static void addUser() {
        String id = readNonEmpty("Enter user ID/name: ");
        if (graph.addUser(id)) {
            System.out.println("User added: " + id);
        } else {
            System.out.println("User already exists.");
        }
    }

    private static void addInteraction() {
        String a = readNonEmpty("First user: ");
        String b = readNonEmpty("Second user: ");
        int weight = readInt("Interaction strength/weight (>= 1): ");

        if (weight < 1) {
            System.out.println("Weight must be at least 1.");
            return;
        }

        if (graph.addInteraction(a, b, weight)) {
            System.out.println("Interaction added/updated: " + a + " <-> " + b
                    + " (weight = " + weight + ")");
        } else {
            System.out.println("Could not add interaction. Check user IDs.");
        }
    }

    private static void removeUser() {
        String id = readNonEmpty("User to remove: ");
        if (graph.removeUser(id)) {
            System.out.println("Removed user and all connected interactions.");
        } else {
            System.out.println("User not found.");
        }
    }

    private static void displayGraph() {
        graph.printGraph();
    }

    private static void traverse() {
        if (graph.size() == 0) {
            System.out.println("Graph is empty.");
            return;
        }

        String start = readNonEmpty("Start user: ");
        if (!graph.containsUser(start)) {
            System.out.println("User not found.");
            return;
        }

        System.out.println("\n1. BFS");
        System.out.println("2. DFS");
        int type = readInt("Choose traversal: ");

        List<String> result = (type == 1)
                ? graph.bfs(start)
                : graph.dfs(start);

        System.out.println("Traversal order: " + String.join(" -> ", result));
    }

    private static void detectCommunities() {
        if (graph.size() == 0) {
            System.out.println("Graph is empty.");
            return;
        }

        LouvainDetector detector = new LouvainDetector(graph);
        Map<String, Integer> communities = detector.detect();
        Metrics.printCommunityReport(graph, communities);
    }

    private static void showMetrics() {
        Map<String, Integer> communities = new LouvainDetector(graph).detect();
        Metrics.printNetworkMetrics(graph);
        Metrics.printCommunityReport(graph, communities);
    }

    private static void loadCSV() throws IOException {
        String path = readNonEmpty("CSV path (example: data/interactions.csv): ");
        int count = graph.loadCSV(path);
        System.out.println("Loaded " + count + " interaction rows.");
    }

    private static void saveCSV() throws IOException {
        String path = readNonEmpty("Output CSV path (example: data/output.csv): ");
        graph.saveCSV(path);
        System.out.println("Graph saved to: " + path);
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid integer.");
            }
        }
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = sc.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("Value cannot be empty.");
        }
    }

    private static void pause() {
        System.out.println("\nPress ENTER to continue...");
        sc.nextLine();
    }
}
