# Community Detection Platform - Java DSA

A console-based Java implementation of the Community Detection Platform described in the DSA-3 project report.

## DSA concepts implemented

1. Weighted undirected graph using adjacency lists
2. BFS traversal using Queue
3. DFS traversal using recursion/stack-like call stack
4. Louvain-style modularity optimization for community detection
5. Network metrics: nodes, edges, density, degree, interaction strength
6. Community metrics: community count, size, internal interaction strength, modularity
7. CSV import/export
8. Add/remove users and interactions at runtime

## Requirements

- Java JDK 17 or newer
- VS Code with Java Extension Pack (recommended)

No external Java libraries are required.

## Run in VS Code terminal

Open the project folder in VS Code and run:

```text
javac *.java
java Main
```

On Windows PowerShell/CMD the commands above work directly.

If you have a different Java installation, verify:

```text
java -version
javac -version
```

## CSV format

The included file is:

```text
data/interactions.csv
```

Format:

```text
source,target,weight
Aarav,Diya,8
Aarav,Kabir,7
```

The program automatically creates users when loading CSV.

## Menu

1. Add user/node
2. Add interaction/weighted edge
3. Remove user/node
4. Display weighted graph
5. BFS / DFS traversal
6. Detect communities (Louvain)
7. Show network & community metrics
8. Load interactions from CSV
9. Save current graph to CSV
0. Exit

## How to demonstrate

1. Start the program.
2. Choose `4` to display the sample weighted graph.
3. Choose `5`, enter `Aarav`, and run BFS.
4. Run DFS from `Aarav`.
5. Choose `6` to detect communities.
6. Choose `7` to show all metrics.
7. Add a new user and interaction using options 1 and 2.
8. Run community detection again to show that the graph changes dynamically.
9. Use option 9 to export the graph.

## Algorithm explanation

### Graph
Users are vertices/nodes. Interactions are undirected weighted edges. A higher weight represents stronger interaction.

### BFS
BFS explores neighbors level by level using a queue.

### DFS
DFS explores as deeply as possible before backtracking.

### Louvain
The implementation starts every node in its own community. It repeatedly evaluates moving a node to a neighboring community and accepts moves that increase modularity. This is repeated until no useful moves remain.

The modularity formula used is:

Q = (1 / 2m) * sum[(Aij - ki*kj/(2m)) * delta(ci,cj)]

where:
- Aij = edge weight between i and j
- ki = weighted degree of i
- kj = weighted degree of j
- m = total edge weight
- ci/cj = communities of i and j

This is an educational Louvain-style implementation for a DSA project. It is not intended to replace optimized production graph libraries.

## Complexity

- Add user: O(1) average
- Add interaction: O(1) average
- Remove user: O(degree)
- BFS: O(V + E)
- DFS: O(V + E)
- Community detection: depends on passes and candidate communities; this educational implementation recomputes modularity, so it is less optimized than production Louvain implementations.

## Project mapping to report

Data Collection -> CSV loader/sample data
Graph Construction -> Graph.java
Edge Weighting -> weighted adjacency list
Community Detection -> LouvainDetector.java
Visualization & Metrics -> console graph/community reports

The project report describes users as nodes and interactions as weighted edges, and highlights BFS/DFS, Louvain clustering, and quality metrics.
